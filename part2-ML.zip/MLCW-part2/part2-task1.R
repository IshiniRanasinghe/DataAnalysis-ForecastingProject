library(readxl)
library(neuralnet)
library(grid)
library(dplyr)
library(MASS)

exchangeUSD_data <- read_excel("ExchangeUSD.xlsx")
str(exchangeUSD_data)

#to scale every feature in dataset
normalize=function(x){
  return((x-min(x))/(max(x)-min(x)))
}
unnormalize = function(x, min, max) { 
  return( (max - min)*x + min )
}

#Extract the "USD/EUR" column
exchangeUSD_df <- exchangeUSD_data[,3]
#exchangeUSD_df
#-----------------------------------------------------------------------------------------
#create matrix for (t-4)
t4_lagged_data <- data.frame(
  Input4 = lag(exchangeUSD_df, 4),
  Input3 = lag(exchangeUSD_df, 3),
  Input2 = lag(exchangeUSD_df, 2),
  Input1 = lag(exchangeUSD_df, 1),
  Predicted_output = exchangeUSD_df
)

#remove NA value rows
t4_lagged_data <- t4_lagged_data[complete.cases(t4_lagged_data),]
colnames(t4_lagged_data) = c("Input1","Input2","Input3","Input4","Output")
#head(t4_lagged_data)
#t4_lagged_data$Input1

#minimum and maximum value of t4_lagged_data
min_t4_lagged_data <- min(t4_lagged_data)
#min_t4_lagged_data
max_t4_lagged_data <- max(t4_lagged_data)
#max_t4_lagged_data

#normalizes t4_lagged_data
normalized_t4_lagged_data <- as.data.frame(lapply(t4_lagged_data,normalize))
#normalized_t4_lagged_data

# this is the desired output of the training dataset
training_Type_t4 = normalized_t4_lagged_data[1:400,] 
testing_Type_t4 = normalized_t4_lagged_data[401:nrow(normalized_t4_lagged_data),]
testing_Type_t4

#i/o mtrix
io_matrix_data_t4 <- rbind(training_Type_t4, testing_Type_t4)
io_matrix_t4 <- io_matrix_data[, c("Input1", "Input2", "Input3", "Input4", "Output")]
#io_matrix_t4

#io_matrix_t4
unnormalized_io_matrix_t4 <- data.frame(
  Input1 = unnormalize(io_matrix_t4$Input1, min_t4_lagged_data, max_t4_lagged_data),
  Input2 = unnormalize(io_matrix_t4$Input2, min_t4_lagged_data, max_t4_lagged_data),
  Input3 = unnormalize(io_matrix_t4$Input3, min_t4_lagged_data, max_t4_lagged_data),
  Input4 = unnormalize(io_matrix_t4$Input4, min_t4_lagged_data, max_t4_lagged_data),
  Output = unnormalize(io_matrix_t4$Output, min_t4_lagged_data, max_t4_lagged_data)
)
# Print the unnormalized I/O matrix
print(unnormalized_io_matrix_t4)


#==============1st MLP with 4 input variables and 1 hidden layer=======================

# Train your neural network model
t4_nn_1 <- neuralnet(Output ~ Input1 + Input2 + Input3 + Input4, 
                     data = training_Type_t4, 
                     hidden = 12, 
                     linear.output = FALSE)

# Plot the model if desired
#plot(t4_nn_1)
# Use the model to make predictions on testing data
t4_nn_1_result <- predict(t4_nn_1, testing_Type_t4)
#t4_nn_1_result

t4_1_original <- unnormalize(t4_nn_1_result,min_t4_lagged_data,max_t4_lagged_data)
#t4_1_original
t4_1_original_rounded <-as.data.frame(sapply(t4_1_original,round,digits=2))
#t4_1_original_rounded

test_data_t4_1_result <- exchangeUSD_df[401:496,]

t4_1_output <- cbind(test_data_t4_1_result,t4_1_original_rounded )
colnames(t4_1_output) = c("Actual","Predicted")
head(t4_1_output)

library(Metrics) 
RMSE_t4_nn_1 = rmse(t4_1_output$Actual, t4_1_output$Predicted)
MAE_t4_nn_1 = mae(t4_1_output$Actual, t4_1_output$Predicted)
MAPE_t4_nn_1 = mape(t4_1_output$Actual, t4_1_output$Predicted)
SMAPE_t4_nn_1= smape(t4_1_output$Actual, t4_1_output$Predicted)
RMSE_t4_nn_1 
MAE_t4_nn_1
MAPE_t4_nn_1
SMAPE_t4_nn_1


#===========2nd MLP with 4 input variables and 2 hidden layer==========================

# Train your neural network model
t4_nn_2 <- neuralnet(Output ~ Input1 + Input2 + Input3 + Input4, 
                     data = training_Type_t4, 
                     hidden = c(5,9), 
                     linear.output = TRUE )

# Plot the model if desired
#plot(t4_nn_2)
# Use the model to make predictions on testing data
t4_nn_2_result <- predict(t4_nn_2, testing_Type_t4)
#t4_nn_2_result

t4_2_original <- unnormalize(t4_nn_2_result,min_t4_lagged_data,max_t4_lagged_data)
#t4_1_original
t4_2_original_rounded <-as.data.frame(sapply(t4_2_original,round,digits=2))
#t4_1_original_rounded

test_data_t4_2_result <- exchangeUSD_df[401:496,]

t4_2_output <- cbind(test_data_t4_2_result,t4_2_original_rounded )
colnames(t4_2_output) = c("Actual","Predicted")
#head(t4_2_output)

library(Metrics) 
RMSE_t4_nn_2 = rmse(t4_2_output$Actual, t4_2_output$Predicted)
MAE_t4_nn_2 = mae(t4_2_output$Actual, t4_2_output$Predicted)
MAPE_t4_nn_2 = mape(t4_2_output$Actual, t4_2_output$Predicted)
SMAPE_t4_nn_2 = smape(t4_2_output$Actual, t4_2_output$Predicted)
RMSE_t4_nn_2 
MAE_t4_nn_2
MAPE_t4_nn_2
SMAPE_t4_nn_2


#===========3rd MLP with 4 input variables and 1 hidden layer==========================

# Train your neural network model
t4_nn_3 <- neuralnet(Output ~ Input1 + Input2 + Input3 + Input4, 
                     data = training_Type_t4, 
                     hidden = 8, 
                     linear.output = TRUE)

# Plot the model if desired
#plot(t4_nn_3)
# Use the model to make predictions on testing data
t4_nn_3_result <- predict(t4_nn_3, testing_Type_t4)
#t4_nn_3_result

t4_3_original <- unnormalize(t4_nn_3_result,min_t4_lagged_data,max_t4_lagged_data)
#t4_1_original
t4_3_original_rounded <-as.data.frame(sapply(t4_3_original,round,digits=2))
#t4_1_original_rounded

test_data_t4_3_result <- exchangeUSD_df[401:496,]

t4_3_output <- cbind(test_data_t4_3_result,t4_3_original_rounded )
colnames(t4_3_output) = c("Actual","Predicted")
#head(t4_3_output)

library(Metrics) 
RMSE_t4_nn_3 = rmse(t4_3_output$Actual, t4_3_output$Predicted)
MAE_t4_nn_3 = mae(t4_3_output$Actual, t4_3_output$Predicted)
MAPE_t4_nn_3 = mape(t4_3_output$Actual, t4_3_output$Predicted)
SMAPE_t4_nn_3 = smape(t4_3_output$Actual, t4_3_output$Predicted)
RMSE_t4_nn_3 
MAE_t4_nn_3
MAPE_t4_nn_3
SMAPE_t4_nn_3

#========================================================================================
#create matrix for (t-3)

t3_lagged_data <- data.frame(
  Input3 = lag(exchangeUSD_df, 3),
  Input2 = lag(exchangeUSD_df, 2),
  Input1 = lag(exchangeUSD_df, 1),
  Predicted_output = exchangeUSD_df
)

#remove NA value rows
t3_lagged_data <- t3_lagged_data[complete.cases(t3_lagged_data),]
colnames(t3_lagged_data) = c("Input1","Input2","Input3","Output")
#head(t3_lagged_data)
#t3_lagged_data$Input1

#minimum and maximum value of t3_lagged_data
min_t3_lagged_data <- min(t3_lagged_data)
#min_t3_lagged_data
max_t3_lagged_data <- max(t3_lagged_data)
#max_t3_lagged_data

#normalizes t3_lagged_data
normalized_t3_lagged_data <- as.data.frame(lapply(t3_lagged_data,normalize))
#normalized_t3_lagged_data

# this is the desired output of the training dataset
training_Type_t3 = normalized_t3_lagged_data[1:400,] 
testing_Type_t3 = normalized_t3_lagged_data[401:nrow(normalized_t3_lagged_data),]
#testing_Type_t3

#i/o mtrix
io_matrix_data_t3 <- rbind(training_Type_t3, testing_Type_t3)
io_matrix_t3 <- io_matrix_data[, c("Input1", "Input2", "Input3", "Input4", "Output")]
#io_matrix_t3
unnormalized_io_matrix_t3 <- data.frame(
  Input1 = unnormalize(io_matrix_t3$Input1, min_t3_lagged_data, max_t3_lagged_data),
  Input2 = unnormalize(io_matrix_t3$Input2, min_t3_lagged_data, max_t3_lagged_data),
  Input3 = unnormalize(io_matrix_t3$Input3, min_t3_lagged_data, max_t3_lagged_data),
  Output = unnormalize(io_matrix_t3$Output, min_t3_lagged_data, max_t3_lagged_data)
)

# Print the unnormalized I/O matrix
print(unnormalized_io_matrix_t3)

#==============4th MLP with 3 input variables and 1 hidden layer=======================

# Train your neural network model
t3_nn_1 <- neuralnet(Output ~ Input1 + Input2 + Input3 , 
                     data = training_Type_t3, 
                     hidden = 12, 
                     linear.output = TRUE)

# Plot the model if desired
plot(t3_nn_1)
# Use the model to make predictions on testing data
t3_nn_1_result <- predict(t3_nn_1, testing_Type_t3)
#t3_nn_1_result

t3_1_original <- unnormalize(t3_nn_1_result,min_t3_lagged_data,max_t3_lagged_data)
#t3_1_original
t3_1_original_rounded <-as.data.frame(sapply(t3_1_original,round,digits=2))
#t3_1_original_rounded

test_data_t3_1_result <- exchangeUSD_df[401:497,]

t3_1_output <- cbind(test_data_t3_1_result, t3_1_original_rounded)
colnames(t3_1_output) <- c("Actual","Predicted")
#head(t3_1_output)

library(Metrics) 
RMSE_t3_nn_1 = rmse(t3_1_output$Actual, t3_1_output$Predicted)
MAE_t3_nn_1 = mae(t3_1_output$Actual, t3_1_output$Predicted)
MAPE_t3_nn_1 = mape(t3_1_output$Actual, t3_1_output$Predicted)
SMAPE_t3_nn_1 = smape(t3_1_output$Actual, t3_1_output$Predicted)
RMSE_t3_nn_1
MAE_t3_nn_1
MAPE_t3_nn_1
SMAPE_t3_nn_1

#==============5th MLP with 3 input variables and 2 hidden layer=======================

# Train your neural network model
t3_nn_2 <- neuralnet(Output ~ Input1 + Input2 + Input3 , 
                     data = training_Type_t3, 
                     hidden = c(8,3), 
                     linear.output = FALSE)

# Plot the model if desired
plot(t3_nn_2)
# Use the model to make predictions on testing data
t3_nn_2_result <- predict(t3_nn_2, testing_Type_t3)
#t3_nn_2_result

t3_2_original <- unnormalize(t3_nn_2_result,min_t3_lagged_data,max_t3_lagged_data)
#t3_2_original
t3_2_original_rounded <-as.data.frame(sapply(t3_2_original,round,digits=2))
#t3_2_original_rounded

test_data_t3_2_result <- exchangeUSD_df[401:497,]

t3_2_output = cbind(test_data_t3_2_result,t3_2_original_rounded)
colnames(t3_2_output) <- c("Actual","Predicted")
head(t3_2_output)

library(Metrics) 
RMSE_t3_nn_2 = rmse(t3_2_output$Actual, t3_2_output$Predicted)
MAE_t3_nn_2 = mae(t3_2_output$Actual, t3_2_output$Predicted)
MAPE_t3_nn_2 = mape(t3_2_output$Actual, t3_2_output$Predicted)
SMAPE_t3_nn_2 = smape(t3_2_output$Actual, t3_2_output$Predicted)
RMSE_t3_nn_2
MAE_t3_nn_2
MAPE_t3_nn_2
SMAPE_t3_nn_2

#==============6th MLP with 3 input variables and 2 hidden layer=======================

# Train your neural network model
t3_nn_3 <- neuralnet(Output ~ Input1 + Input2 + Input3 , 
                     data = training_Type_t3, 
                     hidden = c(2,6), 
                     linear.output = TRUE)

# Plot the model if desired
plot(t3_nn_3)
# Use the model to make predictions on testing data
t3_nn_3_result <- predict(t3_nn_3, testing_Type_t3)
t3_nn_3_result

t3_3_original <- unnormalize(t3_nn_3_result,min_t3_lagged_data,max_t3_lagged_data)
#t4_1_original
t3_3_original_rounded <-as.data.frame(sapply(t3_3_original,round,digits=2))
#t4_1_original_rounded

test_data_t3_3_result <- exchangeUSD_df[401:497,]
#nrow(test_data_t3_1_result)
t3_3_output <- cbind(test_data_t3_3_result,t3_3_original_rounded )
colnames(t3_3_output) = c("Actual","Predicted")
head(t3_3_output)

library(Metrics) 
RMSE_t3_nn_3 = rmse(t3_3_output$Actual, t3_3_output$Predicted)
MAE_t3_nn_3 = mae(t3_3_output$Actual, t3_3_output$Predicted)
MAPE_t3_nn_3 = mape(t3_3_output$Actual, t3_3_output$Predicted)
SMAPE_t3_nn_3 = smape(t3_3_output$Actual, t3_3_output$Predicted)
RMSE_t3_nn_3
MAE_t3_nn_3
MAPE_t3_nn_3
SMAPE_t3_nn_3

#========================================================================================
#create matrix for (t-2)

t2_lagged_data <- data.frame(
  Input2 = lag(exchangeUSD_df, 2),
  Input1 = lag(exchangeUSD_df, 1),
  Predicted_output = exchangeUSD_df
)

#remove NA value rows
t2_lagged_data <- t2_lagged_data[complete.cases(t2_lagged_data),]
colnames(t2_lagged_data) = c("Input1","Input2","Output")
#head(t2_lagged_data)
#t4_lagged_data$Input1

#minimum and maximum value of t4_lagged_data
min_t2_lagged_data <- min(t2_lagged_data)
#min_t4_lagged_data
max_t2_lagged_data <- max(t2_lagged_data)
#max_t4_lagged_data

#normalizes t4_lagged_data
normalized_t2_lagged_data <- as.data.frame(lapply(t2_lagged_data,normalize))
normalized_t2_lagged_data

# this is the desired output of the training dataset
training_Type_t2 = normalized_t2_lagged_data[1:400,] 
testing_Type_t2 = normalized_t2_lagged_data[401:nrow(normalized_t2_lagged_data),]
#testing_Type_t2

#i/o mtrix
io_matrix_data_t2 <- rbind(training_Type_t2, testing_Type_t2)
io_matrix_t2 <- io_matrix_data[, c("Input1", "Input2", "Output")]

unnormalized_io_matrix_t2 <- data.frame(
  Input1 = unnormalize(io_matrix_t2$Input1, min_t2_lagged_data, max_t2_lagged_data),
  Input2 = unnormalize(io_matrix_t2$Input2, min_t2_lagged_data, max_t2_lagged_data),
  Output = unnormalize(io_matrix_t2$Output, min_t2_lagged_data, max_t2_lagged_data)
)

# Print the unnormalized I/O matrix
print(unnormalized_io_matrix_t2)

#==============7th MLP with 2 input variables and 1 hidden layer=======================

# Train your neural network model
t2_nn_1 <- neuralnet(Output ~ Input1 + Input2  , 
                     data = training_Type_t2, 
                     hidden = 10, 
                     linear.output = FALSE)

# Plot the model if desired
plot(t2_nn_1)
# Use the model to make predictions on testing data
t2_nn_1_result <- predict(t2_nn_1, testing_Type_t2)
#t2_nn_1_result

t2_1_original <- unnormalize(t2_nn_1_result,min_t2_lagged_data,max_t2_lagged_data)
#t4_1_original
t2_1_original_rounded <-as.data.frame(sapply(t2_1_original,round,digits=2))
t2_1_original_rounded

test_data_t2_1_result <- exchangeUSD_df[401:498,]

t2_1_output <- cbind(test_data_t2_1_result,t2_1_original_rounded )
colnames(t2_1_output) = c("Actual","Predicted")
#head(t2_1_output)

library(Metrics) 
RMSE_t2_nn_1 = rmse(t2_1_output$Actual, t2_1_output$Predicted)
MAE_t2_nn_1 = mae(t2_1_output$Actual, t2_1_output$Predicted)
MAPE_t2_nn_1 = mape(t2_1_output$Actual, t2_1_output$Predicted)
SMAPE_t2_nn_1 = smape(t2_1_output$Actual, t2_1_output$Predicted)
RMSE_t2_nn_1
MAE_t2_nn_1
MAPE_t2_nn_1
SMAPE_t2_nn_1
#==============8th MLP with 2 input variables and 2 hidden layer=======================

# Train your neural network model
t2_nn_2 <- neuralnet(Output ~ Input1 + Input2  , 
                     data = training_Type_t2, 
                     hidden = c(7,5), 
                     linear.output = TRUE)

# Plot the model if desired
plot(t2_nn_2)
# Use the model to make predictions on testing data
t2_nn_2_result <- predict(t2_nn_2, testing_Type_t2)
#t2_nn_2_result

t2_2_original <- unnormalize(t2_nn_2_result,min_t2_lagged_data,max_t2_lagged_data)
#t4_1_original
t2_2_original_rounded <-as.data.frame(sapply(t2_2_original,round,digits=2))
#t4_1_original_rounded

test_data_t2_2_result <- exchangeUSD_df[401:498,]

t2_2_output <- cbind(test_data_t2_2_result,t2_2_original_rounded)
colnames(t2_2_output) = c("Actual","Predicted")
head(t2_2_output)

library(Metrics) 
RMSE_t2_nn_2 = rmse(t2_2_output$Actual, t2_2_output$Predicted)
MAE_t2_nn_2 = mae(t2_2_output$Actual, t2_2_output$Predicted)
MAPE_t2_nn_2 = mape(t2_2_output$Actual, t2_2_output$Predicted)
SMAPE_t2_nn_2 = smape(t2_2_output$Actual, t2_2_output$Predicted)
RMSE_t2_nn_2
MAE_t2_nn_2
MAPE_t2_nn_2
SMAPE_t2_nn_2

#==============9th MLP with 2 input variables and 3 hidden layer=======================

# Train your neural network model
t2_nn_3 <- neuralnet(Output ~ Input1 + Input2  , 
                     data = training_Type_t2, 
                     hidden = c(2,7,4), 
                     linear.output = TRUE)

# Plot the model if desired
plot(t2_nn_3)
# Use the model to make predictions on testing data
t2_nn_3_result <- predict(t2_nn_3, testing_Type_t2)
#t2_nn_3_result

t2_3_original <- unnormalize(t2_nn_3_result,min_t2_lagged_data,max_t2_lagged_data)
#t2_3_original
t2_3_original_rounded <-as.data.frame(sapply(t2_3_original,round,digits=2))
#t2_3_original_rounded

test_data_t2_3_result <- exchangeUSD_df[401:498,]

t2_3_output <- cbind(test_data_t2_3_result,t2_3_original_rounded )
colnames(t2_3_output) = c("Actual","Predicted")
#head(t2_3_output)

library(Metrics) 
RMSE_t2_nn_3 = rmse(t2_3_output$Actual, t2_3_output$Predicted)
MAE_t2_nn_3 = mae(t2_3_output$Actual, t2_3_output$Predicted)
MAPE_t2_nn_3 = mape(t2_3_output$Actual, t2_3_output$Predicted)
SMAPE_t2_nn_3 = smape(t2_3_output$Actual, t2_3_output$Predicted)
RMSE_t2_nn_3
MAE_t2_nn_3
MAPE_t2_nn_3
SMAPE_t2_nn_3


#========================================================================================
#create matrix for (t-1)

t1_lagged_data <- data.frame(
  Input1 = lag(exchangeUSD_df, 1),
  Predicted_output = exchangeUSD_df
)

#remove NA value rows
t1_lagged_data <- t1_lagged_data[complete.cases(t1_lagged_data),]
colnames(t1_lagged_data) = c("Input1","Output")
head(t1_lagged_data)
#t1_lagged_data$Input1

#minimum and maximum value of t4_lagged_data
min_t1_lagged_data <- min(t1_lagged_data)
#min_t1_lagged_data
max_t1_lagged_data <- max(t1_lagged_data)
#max_t1_lagged_data

#normalizes t1_lagged_data
normalized_t1_lagged_data <- as.data.frame(lapply(t1_lagged_data,normalize))
normalized_t1_lagged_data

# this is the desired output of the training dataset
training_Type_t1 = normalized_t1_lagged_data[1:400,] 
testing_Type_t1 = normalized_t1_lagged_data[401:nrow(normalized_t1_lagged_data),]
#testing_Type_t1

io_matrix_data_t1 <- rbind(training_Type_t1, testing_Type_t1)
io_matrix_t1 <- io_matrix_data[, c("Input1", "Output")]
# Unnormalize the I/O matrix
unnormalized_io_matrix_t1 <- data.frame(
  Input1 = unnormalize(io_matrix_t1$Input1, min_t1_lagged_data, max_t1_lagged_data),
  Output = unnormalize(io_matrix_t1$Output, min_t1_lagged_data, max_t1_lagged_data)
)

# Print the unnormalized I/O matrix
print(unnormalized_io_matrix_t1)

#==============10th MLP with 1 input variables and 1 hidden layer=======================

# Train your neural network model
t1_nn_1 <- neuralnet(Output ~ Input1 , 
                     data = training_Type_t1, 
                     hidden = 15, 
                     linear.output = FALSE)

# Plot the model if desired
plot(t1_nn_1)
# Use the model to make predictions on testing data
t1_nn_1_result <- predict(t1_nn_1, testing_Type_t1)
#t1_nn_1_result

t1_1_original <- unnormalize(t1_nn_1_result,min_t1_lagged_data,max_t1_lagged_data)
#t2_1_original
t1_1_original_rounded <-as.data.frame(sapply(t1_1_original,round,digits=2))
#t1_1_original_rounded

test_data_t1_1_result <- exchangeUSD_df[401:499,]

t1_1_output <- cbind(test_data_t1_1_result,t1_1_original_rounded )
colnames(t1_1_output) = c("Actual","Predicted")
#head(t1_1_output)

library(Metrics) 
RMSE_t1_nn_1 = rmse(t1_1_output$Actual, t1_1_output$Predicted)
MAE_t1_nn_1 = mae(t1_1_output$Actual, t1_1_output$Predicted)
MAPE_t1_nn_1 = mape(t1_1_output$Actual, t1_1_output$Predicted)
SMAPE_t1_nn_1 = smape(t1_1_output$Actual, t1_1_output$Predicted)
RMSE_t1_nn_1
MAE_t1_nn_1
MAPE_t1_nn_1
SMAPE_t1_nn_1


#==============11 th MLP with 1 input variables and 1 hidden layer=======================

# Train your neural network model
t1_nn_2 <- neuralnet(Output ~ Input1 , 
                     data = training_Type_t2 , 
                     hidden = 4, 
                     linear.output = FALSE)

# Plot the model if desired
plot(t1_nn_2)
# Use the model to make predictions on testing data
t1_nn_2_result <- predict(t1_nn_2, testing_Type_t1)
t1_nn_2_result

t1_2_original <- unnormalize(t1_nn_2_result,min_t1_lagged_data,max_t1_lagged_data)
#t1_1_original
t1_2_original_rounded <-as.data.frame(sapply(t1_2_original,round,digits=2))
#t1_1_original_rounded

test_data_t1_2_result <- exchangeUSD_df[401:499,]

t1_2_output <- cbind(test_data_t1_2_result,t1_2_original_rounded )
colnames(t1_2_output) = c("Actual","Predicted")
head(t1_2_output)

library(Metrics) 
RMSE_t1_nn_2 = rmse(t1_2_output$Actual, t1_2_output$Predicted)
MAE_t1_nn_2 = mae(t1_2_output$Actual, t1_2_output$Predicted)
MAPE_t1_nn_2 = mape(t1_2_output$Actual, t1_2_output$Predicted)
SMAPE_t1_nn_2 = smape(t1_2_output$Actual, t1_2_output$Predicted)
RMSE_t1_nn_2
MAE_t1_nn_2
MAPE_t1_nn_2
SMAPE_t1_nn_2



#==============12 th MLP with 1 input variables and 3 hidden layer=======================

# Train your neural network model
t1_nn_3 <- neuralnet(Output ~ Input1 , 
                     data = training_Type_t1 , 
                     hidden = c(9,3,5), 
                     linear.output = TRUE)

# Plot the model if desired
plot(t1_nn_3)
# Use the model to make predictions on testing data
t1_nn_3_result <- predict(t1_nn_3, testing_Type_t1)
t1_nn_3_result

t1_3_original <- unnormalize(t1_nn_3_result,min_t1_lagged_data,max_t1_lagged_data)
#t1_3_original
t1_3_original_rounded <-as.data.frame(sapply(t1_3_original,round,digits=2))
#t1_3_original_rounded

test_data_t1_3_result <- exchangeUSD_df[401:499,]

t1_3_output <- cbind(test_data_t1_3_result,t1_3_original_rounded )
colnames(t1_3_output) = c("Actual","Predicted")
head(t1_3_output)

library(Metrics) 
RMSE_t1_nn_3 = rmse(t1_3_output$Actual, t1_3_output$Predicted)
MAE_t1_nn_3 = mae(t1_3_output$Actual, t1_3_output$Predicted)
MAPE_t1_nn_3 = mape(t1_3_output$Actual, t1_3_output$Predicted)
SMAPE_t1_nn_3 = smape(t1_3_output$Actual, t1_3_output$Predicted)
RMSE_t1_nn_3
MAE_t1_nn_3
MAPE_t1_nn_3
SMAPE_t1_nn_3


#==============================================================================================================

RMSE_all = c(RMSE_t4_nn_1,RMSE_t4_nn_2,RMSE_t4_nn_3,RMSE_t3_nn_1,RMSE_t3_nn_2,RMSE_t3_nn_3,
             RMSE_t2_nn_1,RMSE_t2_nn_2,RMSE_t2_nn_3,RMSE_t1_nn_1,RMSE_t1_nn_2,RMSE_t1_nn_3)

MAE_all =c(MAE_t1_nn_3,MAE_t1_nn_2,MAE_t1_nn_1,MAE_t2_nn_3,MAE_t2_nn_2,MAE_t2_nn_1,
           MAE_t3_nn_3,MAE_t3_nn_2,MAE_t3_nn_1,MAE_t4_nn_3,MAE_t4_nn_2,MAE_t4_nn_1)
MAPE_all = c(MAPE_t4_nn_1,MAPE_t4_nn_2,MAPE_t4_nn_3,MAPE_t3_nn_1,MAPE_t3_nn_2,MAPE_t3_nn_1,
             MAPE_t2_nn_1,MAPE_t2_nn_2,MAPE_t2_nn_1,MAPE_t1_nn_1,MAPE_t1_nn_2,MAPE_t1_nn_3)
SMAPE_all = c(SMAPE_t1_nn_1,SMAPE_t1_nn_2,SMAPE_t1_nn_3,SMAPE_t2_nn_1,SMAPE_t2_nn_2,SMAPE_t2_nn_3,
              SMAPE_t3_nn_1,SMAPE_t3_nn_2,SMAPE_t3_nn_3,SMAPE_t4_nn_1,SMAPE_t4_nn_2,SMAPE_t4_nn_1)

#create the comparison table
comparison_table = data.frame(Model =c("Model 1","Model 2","Model 3","Model 4","Model 5",
                              "Model 6","Model 7","Model 8","Model 9","Model 10",
                              "Model 11","Model 12"),
RMSE = RMSE_all,
MAE = MAE_all,
MAPE = MAPE_all,
SMAPE =SMAPE_all)
comparison_table

#========================================================================================================


#plot for best MLP Model 10
par(mfrow=c(1,1))
plot(t1_1_output$Actual, t1_1_output$Predicted,
     col = 'red',
     main = 'real vs predicted NN',
     pch=18,cex=0.7)
abline(a=0,b=1,h=90,v=90)
#model 10 in graphically
x=1:length(t1_1_output$Actual)
plot(x,t1_1_output$Actual,col='red',type="l",lwd=2,
     main=" USD Exchange Prediction")
lines(x,t1_1_output$Predicted,col='blue',lwd=2)
legend("topright", legend = c("original-strength","predicted-strength"),
       fill = c("red","blue"),col = 2:3,adj = c(0,0.6))
grid()
